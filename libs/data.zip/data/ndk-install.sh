# Script to install NDK into AndroidIDE
# Author MrIkso
echo "进入NDK安装脚本"
cd $HOME


install_dir=$HOME

sdk_dir=$install_dir/android-sdk
cmake_dir=$sdk_dir/cmake
ndk_base_dir=$sdk_dir/ndk

ndk_dir=""
# Ndk版本[也是在$ndk_base_dir下的文件名]
ndk_ver=""
ndk_ver_name=""
ndk_file_name=""
ndk_installed=false
cmake_installed=false

#此安装器固定NDK版本
ndk_ver="$NDK_VERSION_CODE"
ndk_ver_name="$NDK_VERSION_NAME"

link_ndk_() {
	START="\033[32m"
	END="\033[0m"
	
	NDK_OUT_PATH=$1
	NDK_VERSION=$2
	NDK_VERSION_NAME=$3
	
	if [ -d "$NDK_OUT_PATH/$NDK_VERSION_NAME" ]; then
		echo -e "$START已安装NDK-$NDK_VERSION_NAME$END"
		echo ""
	else
		if [ -d "$NDK_OUT_PATH/$NDK_VERSION_NAME" ]; then
			rm -r  $NDK_VERSION_NAME
		fi
		ln -s $NDK_VERSION $NDK_VERSION_NAME
		echo -e "链接 $NDK_VERSION ->  $NDK_VERSION_NAME"
		echo -e "$START以链接方式添加NDK-$NDK_VERSION_NAME$END"
		echo ""
	fi
}

link_ndk() {
	cd $1
	echo "进入$1目录\n"
	link_ndk_ $1 $2 "23.1.7779620"
	link_ndk_ $1 $2 "25.1.8937393"
}

# 下载并安装cmake
run_install_cmake() {
	download_cmake 3.10.2
	download_cmake 3.18.1
	download_cmake 3.22.1
	download_cmake 3.25.1
	download_cmake 3.31.4
	
}

#下载cmake
download_cmake() {
	# download cmake
	cmake_version=$1
	if [ ! -f "cmake-$cmake_version-android-aarch64.zip" ]; then
		echo "开始下载 cmake-$cmake_version..."
		echo "此脚本为离线安装脚本 未下载 cmake-$cmake_version..."
		# wget https://github.com/MrIkso/AndroidIDE-NDK/releases/download/cmake/cmake-"$cmake_version"-android-aarch64.zip --no-verbose --show-progress -N
	else
		echo "已有下载的cmake-$cmake_version-android-aarch64.zip"
	fi
	installing_cmake "$cmake_version"
}

# 安装cmake
installing_cmake() {
	cmake_version=$1
	cmake_file=cmake-"$cmake_version"-android-aarch64.zip
	
	# unzip cmake
	if [ -f "$cmake_file" ]; then
		echo "开始解压 cmake $cmake_version..."
		unzip -q "$cmake_file" -d "$cmake_dir"
		
		echo "删除下载的缓存$cmake_file"
		rm "$cmake_file"
		
		# set executable permission for cmake
		chmod -R +x "$cmake_dir"/"$cmake_version"/bin

		cmake_installed=true
	else
		echo "$cmake_file 不存在."
	fi
}

# 删除cmake缓存
delete_installed_cmake(){
	
if [ -d "$cmake_dir/$1" ]; then
	echo "$cmake_dir/$1 exists. 删除已安装的cmake-$1..."
	rm -rf "$cmake_dir/$1"
fi
	
}

echo "版本$ndk_ver_name ($ndk_ver) 安装"
echo '警告！此 NDK 仅适用于 aarch64'
cd "$install_dir" || exit


# checking if previous installed NDK and cmake
ndk_dir="$ndk_base_dir/$ndk_ver"
ndk_file_name="android-ndk-$ndk_ver_name-aarch64.zip"

if [ -d "$ndk_dir" ]; then
	echo "$ndk_dir exists. 删除已安装的NDK($ndk_ver)..."
	rm -rf "$ndk_dir"
else
	echo "不存在已安装的NDK $ndk_ver."
fi

if [ -d "$cmake_dir/3.10.2" ]; then
	echo "$cmake_dir/3.10.2 exists. 删除已安装的cmake..."
	
	rm -rf "$cmake_dir/3.10.2"
fi

if [ -d "$cmake_dir/3.18.1" ]; then
	echo "$cmake_dir/3.18.1 exists. 删除已安装的cmake..."
	rm -rf "$cmake_dir/3.18.1"
fi

if [ -d "$cmake_dir/3.22.1" ]; then
	echo "$cmake_dir/3.22.1 exists. 删除已安装的cmake..."
	rm -rf "$cmake_dir/3.22.1"
fi

if [ -d "$cmake_dir/3.25.1" ]; then
	echo "$cmake_dir/3.25.1 exists. 删除已安装的cmake..."
	rm -rf "$cmake_dir/3.25.1"
fi

# download NDK
if [ ! -f "$ndk_file_name" ]; then
	echo "开始下载 NDK $ndk_ver_name..."
	echo "此脚本为离线安装脚本 未下载NDK $ndk_ver_name..."
	#wget https://github.com/jzinferno2/termux-ndk/releases/download/v1/$ndk_file_name --no-verbose --show-progress -N
else
	echo "已有下载的NDK $ndk_ver_name..."
fi

# 禁用解压NDK，用于测试cmake
# ndk_file_name="测试cmake解压"

# 解压Ndk
if [ -f "$ndk_file_name" ]; then
	echo "开始解压 NDK $ndk_ver_name..."
	unzip -qq $ndk_file_name
	
	# set executable permission for cmake
	chmod -R +x $ndk_file_name
	
	echo "删除下载的缓存$ndk_file_name"
	rm $ndk_file_name

	# moving NDK to Android SDK directory
	if [ -d "$ndk_base_dir" ]; then
		mv android-ndk-$ndk_ver_name "$ndk_dir"
		chmod -R +x "$ndk_dir"
	else
		echo "NDK base dir 不存在. Creating..."
		mkdir -p "$sdk_dir"/ndk
		mv android-ndk-$ndk_ver_name "$ndk_dir"
	fi

	# create missing link
	if [ -d "$ndk_dir" ]; then
		echo "创建缺失的链接..."
		cd "$ndk_dir"/toolchains/llvm/prebuilt || exit
		
		ln -s linux-aarch64 linux-x86_64
		
		cd "$ndk_dir"/prebuilt || exit
		
		ln -s linux-aarch64 linux-x86_64
		cd "$install_dir" || exit

		# patching cmake config
		echo "修补 cmake 配置..."
		sed -i 's/if(CMAKE_HOST_SYSTEM_NAME STREQUAL Linux)/if(CMAKE_HOST_SYSTEM_NAME STREQUAL Android)\nset(ANDROID_HOST_TAG linux-aarch64)\nelseif(CMAKE_HOST_SYSTEM_NAME STREQUAL Linux)/g' "$ndk_dir"/build/cmake/android-legacy.toolchain.cmake
		sed -i 's/if(CMAKE_HOST_SYSTEM_NAME STREQUAL Linux)/if(CMAKE_HOST_SYSTEM_NAME STREQUAL Android)\nset(ANDROID_HOST_TAG linux-aarch64)\nelseif(CMAKE_HOST_SYSTEM_NAME STREQUAL Linux)/g' "$ndk_dir"/build/cmake/android.toolchain.cmake
		
		# link_ndk $ndk_base_dir $ndk_ver
		ndk_installed=true
		
	else
		echo "NDK $ndk_ver不存在，不用删除."
	fi
else
	echo "$ndk_file_name 不存在."
fi

if [ -d "$cmake_dir" ]; then
	cd "$cmake_dir"
	run_install_cmake
else
	mkdir -p "$cmake_dir"
	cd "$cmake_dir"
	run_install_cmake
fi

if [[ $ndk_installed == true && $cmake_installed == true ]]; then
	echo '安装完成。 NDK已安装成功!'
else
	echo 'NDK和cmake安装失败!'
fi

